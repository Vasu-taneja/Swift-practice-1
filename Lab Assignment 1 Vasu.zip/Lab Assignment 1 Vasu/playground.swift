import Foundation

class Player {
    var name: String
    var health: Int
    init () {
        name = ""
        health = 0 
    }
        var getSetName: String {
            get {
                return name
            }
            set (newName) {
            let invalidNames = CharacterSet.decimalDigits
            let isInvalid = newName.rangeOfCharacter(from: invalidNames)
            if !newName.isEmpty && isInvalid == nil {
                name = newName
            } else {
                print("Invalid Input!")
            }
        }
    }
    
    var getHealth: Int {
        get {
            return health;
        }
    }
    func affectHealth(healthParam: Int) -> Int {
        health = healthParam * 2
        return health
    }
    func toString() {
        let playersJsonObject = "{playerDetails:{\"name\": \"\(name)\",\"health\":\(health)}}"
        print(playersJsonObject)
    }
}
var testPlayer = Player()
testPlayer.getSetName = "Joe1"
var playerName = testPlayer.name
var playerHealth = testPlayer.affectHealth(healthParam: 100)
print(playerName)
print(playerHealth)
testPlayer.toString()
